###### Random walk (wiener process/Brownian motion)

$$
X_t = X_{t-1} + \mu +\epsilon(t)
$$


$$
v-drift.rate
\\

\alpha-boundary
\\

z-start point
\\


T_{er}-non.decision.time
$$

$$
v = v_{mod} * (value_{hamburg} - value_{salad})
$$

$$
alpha(t) = e^{-rt} 
\\
r \in \mathbb{R+}
$$



$$
Wiener(RT|v,alpha,z,T_{er})
$$

$$
Q_{t} = Q_{t-1} + alpha * PE \\
PE = f_{t}-Q_{t-1}
$$





$$
Y_n = \theta*X_n + \epsilon_n
$$

$$
\min _{\theta} \frac{1}{N}\sum_{n=1}^{N}\left(y_{n}-\theta x_{n}\right)^{2}
$$




$$

$$

$$
\frac{d}{d\theta}\frac{1}{N}\sum_{i=1}^N(y_i - \theta x_i)^2 = 0 \\
$$

$$
\frac{1}{N}\sum_{i=1}^N-2x_i(y_i - \theta x_i) = 0
$$


$$
\hat\theta = \frac{\sum_{i=1}^N x_i y_i}{\sum_{i=1}^N x_i^2}



\\
\\
\hat\theta = \frac{\vec{x}^\top \vec{y}}{\vec{x}^\top \vec{x}}
$$



$$
\epsilon \sim \mathcal{N}(0, 1).
$$

$$
p(y|x,\theta) = \frac{1}{\sqrt{2\pi}}e^{-\frac{1}{2}(y-\theta x)^2}
$$



$$
\mathcal{N}(x; \mu, \sigma^2) = \frac{1}{\sqrt{2\pi\sigma^2}}e^{-\frac{1}{2\sigma^2}(x-\mu)^2}
$$



$$
\mathcal{L}(\theta|X,Y) = \prod_{i=1}^N \mathcal{L}(\theta|x_i,y_i)\\

\operatorname{log}\mathcal{L}(\theta|X,Y) = \sum_{i=1}^N \operatorname{log}\mathcal{L}(\theta|x_i,y_i)
$$



$$
\hat{\theta}_{\textrm{MLE}} = \underset{\theta}{\operatorname{argmax}} [-\frac{N}{2} \operatorname{log} 2\pi\sigma^2 - \frac{1}{2\sigma^2}\sum_{i=1}^N (y_i-\theta x_i)^2].
$$




### Logistic regression model





X为连续随机变量，X服从logistic regression distribution


$$
F(x) = P(X<=x) = \frac{1}{1+e^{-(x-\mu)/\gamma}}
$$


$\gamma-shape$



$P(choice=1|value. difference) = F(value.difference)$

$P(choice=0|value. difference) = 1-F(value.difference)$



Likelihood function​

$P(choice = choice_{i}|value.difference)= Bernoulli .function$

$=F(value.difference)^{choice_{i}}*[1-F(value.difference)^{1-choice_{i}}]$




$$
v = v_{mod} * (value_{correct} - value_{incorrect})
$$



$$
alpha(t) = e^{-rt} 
$$







$$
P(t) = \frac{exp^{Q_{1}\beta}}{exp^{Q_{1}\beta}+exp^{Q_{2}\beta}}
$$
