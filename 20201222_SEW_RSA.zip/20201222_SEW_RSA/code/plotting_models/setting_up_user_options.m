%Feng edited. adapted from projectOptions_demo functions



%projectOptions_demo is a nullary function which initialises a struct
% containing the preferences and details for a particular project; in this case
% the demo for the toolbox. It should be edited to taste before a project is
% run, and a new one created for each substantially different project (though
% the options struct will be saved each time the project is run under a new
% name, so all will not be lost if you don't do this).
%
% For a guide to how to fill out the fields in this file, consult the
% documentation pages.
%
% Cai Wingfield 11-2009, 6-2010, 7-2010
%__________________________________________________________________________
% Copyright (C) 2010 Medical Research Council

function userOptions = setting_up_user_options(subjectNames,conditionNames,img_path)

%% Project details
% This name identifies a collection of files which all belong to the same run of a project.
userOptions.analysisName = 'behav_model_test_plotting'; % analysis name.

% This is the root directory of the project.
userOptions.rootPath = '/home/fengchunliang/Feng_working_space/Self-fMRI-Data/RDManalysis_behavioral_model/batches/test_plotting'; %not set for each subject. Instead, a real root path

% The path leading to where the scans are stored (not including subject-specific identifiers).
% "[[subjectName]]" should be used as a placeholder to denote an entry in userOptions.subjectNames
% "[[betaIdentifier]]" should be used as a placeholder to denote an output of betaCorrespondence.m if SPM is not being used; or an arbitrary filename if SPM is being used.
userOptions.betaPath = [img_path,filesep,'[[subjectName]]',filesep,'first_level_for_MVPA_analysis_46contrasts',filesep,'[[betaIdentifier]]'];  % go to getDataFromSPM.m for this one.
userOptions.maskPath =[img_path,filesep,'[[subjectName]]',filesep,'first_level_for_MVPA_analysis_46contrasts',filesep,'[[maskName]].nii'];
userOptions.maskNames = { ...
    'mask',...
    };

userOptions.structuralsPath = [img_path,filesep,'[[subjectName]]',filesep,'t1_mpr_ns_sag_renamed_path'];  % path to T1 image. remain T1 paths of all subjects to a same name: e.g., t1_path
% What are the dimensions (in mm) of the voxels in the scans?
userOptions.voxelSize = [3.44 3.44 5]; %This is the voxel size in the native space.
userOptions.voxelSize2 = [3 3 3]; %This is the voxel size after normalization.
% What radius of searchlight should be used (mm)?
userOptions.searchlightRadius = 15;

userOptions.smoothingKernel_fwhm=[8 8 8]; %smoothing parameter. This was done after second-order RDM calculations.


%%%%%%%%%%%%%%%%%%%%%%%%
%% EXPERIMENTAL SETUP %%
%%%%%%%%%%%%%%%%%%%%%%%%

% The list of subjects to be included in the study.
userOptions.subjectNames = subjectNames;


% The default colour label for RDMs corresponding to ROI masks (as opposed to models).
userOptions.RoIColor = [0 0 1]; %come back later
userOptions.ModelColor = [0 1 0]; %Will be used in the constructModelRDMs.m, not sure what it exactly means.

%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ANALYSIS PREFERENCES %%
%%%%%%%%%%%%%%%%%%%%%%%%%%

%% First-order analysis

% Text lables which may be attached to the conditions for MDS plots.
userOptions.conditionLabels = conditionNames; %set exactly the names of 9 conditions in our study. These will be used for plotting MDS

% % Should information about the experimental design be automatically acquired from SPM metadata?
% % If this option is set to true, the entries in userOptions.conditionLabels MUST correspond to the names of the conditions as specified in SPM.
 userOptions.getSPMData = true;

[userOptions.alternativeConditionLabels{1:9}] = deal(' '); %Text lables which may be attached to the conditions for MDS plots.
userOptions.useAlternativeConditionLabels = true; %come back later

% Colours for the conditions.
userOptions.conditionColours = kron([1 0 0; 0 1 0; 0 0 1], ones(3,1)); %same color for each category (9 in total, same color for same targets in different domains).

% Groups to plot convex hulls around
userOptions.convexHulls = [ones(1,3) 2*ones(1,3) 3*ones(1,3)]; %come back later see MDSConditions for details.

% Which distance measure to use when calculating first-order RDMs.
% %first-order RDMs should mean brain RDMs
userOptions.distance = 'Correlation'; %this can be other distance measures. This option does not work, see also fMRISearchlight.m

%% Second-order analysis

% Which similarity-measure is used for the second-order comparison.
userOptions.distanceMeasure = 'Spearman'; %This option does not work, see also fMRISearchlight.m

% How many permutations should be used to test the significance of the fits?  (10,000 highly recommended.)
userOptions.significanceTestPermutations = 10000; % should be 10000 %come back later

% Should RDMs' entries be rank transformed into [0,1] before they're displayed?
userOptions.rankTransform = true; %come back later, refer to the paper.

% RDM Colourscheme
userOptions.colourScheme = jet(9); %set up colormap, a 9*3 matrix, each row corresponding to RGB values (0~1); userOptions.colourScheme = bone(128);

% Should rubber bands be shown on the MDS plot? multidemional scaling
userOptions.rubberbands = true;

% What criterion shoud be minimised in MDS display?
userOptions.criterion = 'metricstress'; %come back later

% How should figures be outputted?
userOptions.displayFigures = false;
userOptions.saveFiguresPDF = true;
userOptions.saveFiguresFig = false;
userOptions.saveFiguresPS = false;
userOptions.saveFiguresEps = false;

% Bootstrap options
userOptions.nResamplings = 1000;
userOptions.resampleSubjects = true;
userOptions.resampleConditions = true;

% Ceiling Estimation
% Ceiling Estimation
userOptions.RDMname = 'referenceRDM';
userOptions.plottingStyle = 2; %come back later

% Which dots per inch resolution do we output?
userOptions.dpi = 300;
% Remove whitespace from PDF/PS files?
% Bad if you just want to print the figures since they'll
% no longer be A4 size, good if you want to put the figure
% in a manuscript or presentation.
userOptions.tightInset = true;

% userOptions.forcePromptReply = 'R';