%% this tiny script is to test plotting of RDM.

%% Initialisation %%
%%%%%%%%%%%%%%%%%%%%

toolboxRoot = '/home/fengchunliang/Feng_working_space/SPM_related'; addpath(genpath(toolboxRoot)); %set SPM path

toolpath='/home/fengchunliang/Feng_working_space/Self-fMRI-Data/RDManalysis/rsatoolbox';
addpath(genpath(toolpath)); %set toolbox path


clear;
clc;


%% Generate a userOptions structure
img_path='/home/fengchunliang/Feng_working_space/Self-fMRI-Data/fMRI_data_both_culture_and_gene';

subfolders=dir([img_path,'/*K32*']);

for tempss=1:length(subfolders)
    subjectNames{tempss}=subfolders(tempss).name; %set up all subjects names
end

conditionNames={'ss','ms','ps','sm','mm','pm','sl','ml','pl'}; % conditions

userOptions = setting_up_user_options(subjectNames,conditionNames,img_path);%please see also userOptions_guide.m for details.

%% RDM calculation, this will give you model RDMs, could be more than one%%
Models = constructModelRDMs(modelRDMs(), userOptions); %modelRDMs.m needs to be modified from modelRDM_DEMO2.m file.

figureRDMs(Models, userOptions); %plot the matrixs, display them and save them to a .pdf file.

MDSConditions(Models, userOptions);
dendrogramConditions(Models, userOptions);





