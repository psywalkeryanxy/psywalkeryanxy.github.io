
%% adapted from DEMO4_RSAsearchlight_sim, Chunliang Feng, 20160623
%see also Recipe_fMRI_searchlight.m in the Recipes folder

%% DEMO4_RSAsearchlight_sim
% simulates fMRI data for a number of subjects and runs searchlight
% analysis using RSA, computes the similarity maps for each subject
% and does group level inference.

% demo of the searchlight analysis
%%%%%%%%%%%%%%%%%%%%
%% Initialisation %%
%%%%%%%%%%%%%%%%%%%%

toolboxRoot = '/home/fengchunliang/Feng_working_space/SPM_related'; addpath(genpath(toolboxRoot)); %set SPM path

toolpath='/home/fengchunliang/Feng_working_space/Self-fMRI-Data/RDManalysis/rsatoolbox';
addpath(genpath(toolpath)); %set toolbox path

clear;clc
returnHere = pwd; % We'll come back here later


%% Generate a userOptions structure
img_path='/home/fengchunliang/Feng_working_space/Self-fMRI-Data/fMRI_data_both_culture_and_gene';

subfolders=dir([img_path,'/*K32*']);

for tempss=1:length(subfolders)
    subjectNames{tempss}=subfolders(tempss).name; %set up all subjects names
end

conditionNames={'ss','ms','ps','sm','mm','pm','sl','ml','pl'}; %please note that font condition was not included. The toolbox will search for these conditions in the SPM.mat

userOptions = setting_up_user_options(subjectNames,conditionNames,img_path);%please see also userOptions_guide.m for details.



%%%%%%%%%%%%%%%%%%%%%%
%% Data preparation %%
%%%%%%%%%%%%%%%%%%%%%%
%1. all beta images (all subjects, all conditions, all sessions) will be saved to a single .mat file. each beta image will be saved as a vector.
fullBrainVols = fMRIDataPreparation('SPM', userOptions); % please use the edited getDataFromSPM.mat to get rid of potential bugs.

%2. all mask images (all subjects) will be saved to a single .mat file. Each mask image will be saved as a matrix with values of 0 or 1.
binaryMasks_nS = fMRIMaskPreparation(userOptions);

%3. %% RDM calculation, this will give you model RDMs, could be more than one%%
models = constructModelRDMs(modelRDMs(), userOptions); %modelRDMs.m needs to be modified from modelRDM_DEMO2.m file.

%responsePatterns = fMRIDataMasking(fullBrainVols, binaryMasks_nS,'SPM',userOptions); probably makes more sense in the ROI analysis.


%%%% 4. Searchlight, do it for all subjects at once %%%
fMRISearchlight(fullBrainVols, binaryMasks_nS, models, 'SPM', userOptions);  %Saved are native-space and standard-space r-maps for each model. Please note that r maps have been Fisher transformed so that they can be used for statistical inference. 

cd(returnHere);

