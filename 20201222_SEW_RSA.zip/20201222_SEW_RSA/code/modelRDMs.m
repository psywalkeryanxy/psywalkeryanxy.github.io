%  modelRDMs is a user-editable function which specifies the models which
%  brain-region RDMs should be compared to, and which specifies which kinds of
%  analysis should be performed.
%
%  Models should be stored in the "Models" struct as a single field labeled
%  with the model's name (use underscores in stead of spaces).
%
%  Cai Wingfield 11-2009
%conditionNames={'ss','ms','ps','sm','mm','pm','sl','ml','pl'};
function Models = modelRDMs()

ACC_mod=load([pwd,filesep,'ACC_model.txt']);
[f_r,f_p]=corrcoef(ACC_mod);
Models.ACC=1-f_r;  % ACC model;

RT_mod=load([pwd,filesep,'RT_model.txt']);
[s_r,s_p]=corrcoef(RT_mod);
Models.RT=1-s_r;  % RT model;

% Eff_mod=load([pwd,'/Efficiency_model.txt']);
% [s_r,s_p]=corrcoef(Eff_mod);
% Models.Eff=1-s_r;  % Efficiency model;

Q1_mod=load([pwd,filesep,'Q1_model.txt']);
[s_r,s_p]=corrcoef(Q1_mod);
Models.Q1_frequency_=1-s_r;  % Q1 model;

Q2_mod=load([pwd,filesep,'Q2_model.txt']);
[s_r,s_p]=corrcoef(Q2_mod);
Models.Q2_fitness=1-s_r;  % Q2 model;

Q3_mod=load([pwd,filesep,'Q3_model.txt']);
[s_r,s_p]=corrcoef(Q3_mod);
Models.Q3_uncertainty=1-s_r;  % Q3 model;

Q4_mod=load([pwd,filesep,'Q4_model.txt']);
[s_r,s_p]=corrcoef(Q4_mod);
Models.Q4_memory=1-s_r;  % Q4 model;

Q5_mod=load([pwd,filesep,'Q5_model.txt']);
[s_r,s_p]=corrcoef(Q5_mod);
Models.Q5_vividness=1-s_r;  % Q5 model;

Models.random = squareform(pdist(rand(9,9)));